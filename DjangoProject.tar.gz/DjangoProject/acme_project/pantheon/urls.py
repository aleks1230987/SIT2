from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('figures/', views.figure_list, name='figure_list'),
    path('statistics/', views.statistics_view, name='statistics'),
]
