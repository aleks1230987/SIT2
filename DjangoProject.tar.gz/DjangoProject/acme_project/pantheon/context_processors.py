
def pantheon_context(request):
    "
    from .models import HistoricalFigure
    
    return {
        'total_figures_global': HistoricalFigure.objects.count(),
        'current_year': datetime.datetime.now().year,
        'app_version': '1.0.0',
    }
